package spring.boot.webflux;

import java.util.stream.Stream;

import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.core.io.ClassPathResource;
import org.springframework.data.r2dbc.connectionfactory.init.ConnectionFactoryInitializer;
import org.springframework.data.r2dbc.connectionfactory.init.ResourceDatabasePopulator;
import org.springframework.data.r2dbc.core.DatabaseClient;

import io.r2dbc.spi.ConnectionFactory;
import reactor.core.publisher.Flux;
import spring.boot.webflux.model.Todo;
import spring.boot.webflux.repository.TodoRepository;

@SpringBootApplication
public class Application {

    public static void main(String[] args) {
        SpringApplication.run(Application.class, args);
    }

    @Bean
    ApplicationRunner init(TodoRepository repository, DatabaseClient client) {
        return args -> {
            client.execute("create table IF NOT EXISTS TODO" +
                    "(id SERIAL PRIMARY KEY, text varchar (255) not null, completed boolean default false);").fetch().first().subscribe();
            client.execute("DELETE FROM TODO;").fetch().first().subscribe();

            Stream<Todo> stream = Stream.of(new Todo(null, "My first Todo Task !", false),
                    new Todo(null, "My second Todo Task !", true),
                    new Todo(null, "My third Todo Task ", false),
                    new  Todo(null, "My forth Todo Task !", true),
            new  Todo(null, "My fifth Todo Task !", false),
            new  Todo(null, "My sixth Todo Task !", true),
            new  Todo(null, "My seventh Todo Task !", true),
            new  Todo(null, "My eighth Todo Task !", false),
            new  Todo(null, "My nineth Todo Task !", false));

            // initialize the database

            repository.saveAll(Flux.fromStream(stream))
                    .then()
                    .subscribe(); // execute

        };
    }
    
    
    

}